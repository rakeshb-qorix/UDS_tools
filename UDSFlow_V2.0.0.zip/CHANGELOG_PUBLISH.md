# UDSFlow 2.0.0 — Customer Release Notes & Feature Guide

Welcome to **UDSFlow 2.0.0**, a major release designed to provide an enterprise-grade, high-performance UDS (ISO 14229-1) automotive testing experience in a single standalone executable application.

Version 2.0.0 introduces instant launch execution, microsecond-accurate bus trace alignment, seamless legacy 32-bit seed-key algorithm support, and a feature-rich script editor tailored for automotive test automation engineers.

---

## 🌟 Key User-Facing Capabilities & Enhancements

### ⚡ Instant Executable Launch & Splash Screen
Experience near-instant application responsiveness upon double-clicking `UDSFlow.exe`. Version 2.0.0 introduces an accelerated startup pipeline featuring a polished splash screen animation, eliminating initial loading delay and bringing up the primary workspace seamlessly.

### 📜 Vector CANoe-Compatible Trace Logging (`.asc` & `.log`)
Perform frame-accurate trace analysis with native support for Vector log formats. UDSFlow now records test traffic in dual formats simultaneously:
- **Standard Log (`.log`)**: Human-readable test execution log.
- **Vector ASCII Trace (`.asc`)**: Microsecond-accurate trace log fully compatible with Vector CANoe and CANalyzer, recording exact channel assignments, data length codes (DLC), nominal/data bitrates, and transmit/receive frame directions (`Rx`/`Tx`).

### ⏱️ Bus-Accurate Microsecond Timestamps in Test Reports
Test report generation has been upgraded to record true physical bus timestamps. Generated HTML and PDF reports extract microsecond-fidelity frame execution times directly from bus trace logs, providing an absolute audit trail for every UDS request sent and ECU response received.

### 🔌 Seamless Legacy 32-Bit (x86) Seed-Key DLL Integration
Connect legacy security access algorithms effortlessly. The 64-bit application transparently loads and executes 32-bit (x86) Windows DLL seed-key algorithms. Fully supports multi-level security access, dynamic function signature resolution, and custom per-level key size configurations.

### 🛠️ Interactive Script Editor & Test Suite Automation
Author, edit, and duplicate test automation suites with speed and precision:
- **1-Click Step & Test Case Duplication**: Instantly clone individual diagnostic steps or entire multi-step test cases. Fresh unique IDs and non-conflicting names (e.g. `TC_01_Copy_1`) are assigned automatically.
- **Selective Test Execution ("Selective Run")**: Easily select or deselect specific test cases or sub-suites using interactive UI checkboxes before running automated test runs.
- **Preset UDS Templates & Schema Reference**: Built-in template library and quick-reference guide for instant creation of UDS diagnostic sessions, security access routines, DID read/write, and routine controls.
- **Automated Firmware Flashing**: Built-in support for Motorola S19 firmware download sequences, incorporating Request Download (0x34), Transfer Data (0x36), and Transfer Exit (0x37) routines.

### 🚀 High-Capacity Stress Testing Engine (>100,000 Steps)
Engineered for rigorous endurance validation. The optimized execution engine handles massive test suites exceeding 100,000 steps smoothly, maintaining a constant 60 FPS user interface response without freezing or memory slowdown.

### 🎯 Additional Usability Enhancements
- **Manual Testing (MT) Delay Button**: Added a dedicated Delay button in the sequence builder for millisecond-precision pauses between steps.
- **Copyable Activity Log**: Activity log text can now be selected and copied directly to the clipboard for fast debugging.
- **Certified Windows Binary Metadata**: Embedded executable metadata prevents false-positive security warnings in Windows Defender and SmartScreen.

---

## 🛠️ Summary of Key Features

| Domain | Feature Summary |
| :--- | :--- |
| **Application Launch** | Instant launch execution with smooth animated splash screen |
| **Trace Logging** | Dual Vector `.asc` trace format and standard `.log` format |
| **Test Reports** | Microsecond bus trace timestamping in HTML & PDF reports |
| **Security Access** | Seamless 32-bit (x86) Seed-Key DLL execution on 64-bit systems |
| **Script Editor** | One-click Step & Test Case duplication and selective test execution |
| **Firmware Flashing** | Motorola S19 binary parsing with multi-block transfer execution |
| **Manual Testing** | Millisecond-precision Delay step action button |
| **User Interface** | Selectable & copyable activity log output |

---

## 📋 System Requirements & Compatibility
- **Operating System**: Windows 11 (64-bit)
- **Supported Hardware**: Vector CAN Hardware (Vector Driver)
- **Supported Protocols**: ISO 14229-1 (UDS), ISO 15765-2 (ISO-TP)

---
*UDSFlow 2.0.0 — Enterprise UDS Automotive Diagnostic & Test Automation Tool.*
