# (c) Copyright 2026 UDSFlow. All rights reserved.
#
# sa_plugin_sample.py
# --------------------------------------------------------------------------
# Sample Security Access (UDS 0x27) seed-to-key plugin for UDSFlow.
#
# USAGE
# -----
# 1. Copy this file and rename it to match your ECU  (e.g. my_ecu_sa.py).
# 2. Adapt _compute_key() if your ECU uses a different algorithm.
# 3. Select the file via CAN Connection → Security Access Plugin (0x27).
#
# PLUGIN CONTRACT
# ---------------
# The tool calls:
#   seed_to_key(seed: bytes, level: int, variant: str = "") -> bytes
#
# Parameters
#   seed     Raw seed bytes received from the ECU in the 0x67 response.
#   level    Security access level that was requested (1, 3, 5, …).
#   variant  Optional ECU variant string configured in the tool (may be "").
#
# Return value
#   Key bytes to be sent in the 0x27 sendKey request.
#   Must be of type bytes or bytearray.
#
# Exceptions
#   Raise ValueError for invalid / unexpected inputs.
#   Any unhandled exception is caught by the tool and reported as a step
#   failure — the ECU lockout counter is NOT incremented in that case.
#
# ALGORITHM (per byte, all arithmetic is 8-bit / mod 256)
# --------------------------------------------------------
# Ported from the reference C implementation:
#
#   for each byte TempSeed in seed:
#       XorResult  = TempSeed ^ 0xAE
#       ShiftRight = TempSeed >> 2
#       ShiftLeft  = (TempSeed << 4) & 0xFF
#       key_byte   = XorResult | ShiftRight | ShiftLeft
#
# This is a single-pass, position-independent, byte-wise transform — the
# same algorithm is applied to every seed byte regardless of its index.
# --------------------------------------------------------------------------

from __future__ import annotations


# ---------------------------------------------------------------------------
# Per-level key size configuration
#
# Set a level's value to 0 to produce a key of the same length as the seed
# (default behaviour).  Set it to a fixed integer when the ECU expects a
# specific key length regardless of the seed length it sent.
#
# Example — ECU expects a 4-byte key no matter what seed it sends:
#   KEY_SIZE_CONFIG = {1: 4, 2: 4}
#
# When key_size > len(seed) the algorithm wraps the seed (seed[i % len(seed)]).
# When key_size < len(seed) the algorithm truncates after key_size bytes.
# ---------------------------------------------------------------------------
KEY_SIZE_CONFIG: dict[int, int] = {
    1: 0,   # 0 = same length as seed
    2: 4,   # 0 = same length as seed
}

def _compute_key(seed: bytes, level: int, variant: str, key_size: int = 0) -> bytes:  # noqa: ARG001
    """Core key derivation — adapt this function for your ECU.

    Parameters
    ----------
    key_size : int
        Desired output length in bytes.  0 (default) means same as len(seed).
        When key_size > len(seed) the seed is wrapped (seed[i % len(seed)]).
        When key_size < len(seed) only the first key_size bytes are produced.
    """
    if len(seed) == 0:
        raise ValueError("Seed is empty — ECU may already be unlocked at this level.")

    out_size = key_size if key_size > 0 else len(seed)
    key = bytearray(out_size)
    for i in range(out_size):
        byte        = seed[i % len(seed)]  # wrap seed if key longer than seed
        xor_result  = (byte ^ 0xAE) & 0xFF
        shift_right = (byte >> 2)   & 0xFF
        shift_left  = (byte << 4)   & 0xFF
        key[i]      = (xor_result | shift_right | shift_left) & 0xFF

    return bytes(key)


# ---------------------------------------------------------------------------
# Plugin entry point (called by security_access_helper.SecurityAccessPlugin)
# ---------------------------------------------------------------------------

def seed_to_key(seed: bytes, level: int, variant: str = "") -> bytes:
    """
    Derive the security access key from the seed.

    Parameters
    ----------
    seed    : bytes — raw seed received from the ECU (0x67 response payload
              after stripping the SID byte 0x67 and sub-function byte).
    level   : int   — logical security access level index (1, 2, 3, …).
              Level 1 → UDS sub-fn 0x01/0x02 (27 01 / 27 02).
              Level 2 → UDS sub-fn 0x03/0x04 (27 03 / 27 04).
    variant : str   — ECU variant string from the tool config (may be empty).

    Returns
    -------
    bytes — key bytes to send in the 0x27 sendKey request.
    """
    # Optional: per-level dispatch if your ECU uses different algorithms.
    # Remove the 'if' block and use _compute_key directly for single-level ECUs.
    key_size = KEY_SIZE_CONFIG.get(level, 0)
    if level == 1:
        return _compute_key(seed, level, variant, key_size)
    elif level == 2:
        # Level 2 corresponds to UDS sub-function 0x03 (27 03 / 27 04).
        # Change the algorithm here if level 2 uses a different derivation.
        return _compute_key(seed, level, variant, key_size)
    else:
        raise ValueError(
            f"Security access level {level} is not supported by this plugin. "
            f"Supported levels: 1, 2."
        )
